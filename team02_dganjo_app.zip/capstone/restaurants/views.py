from django.shortcuts import render
from django.http import HttpResponse
from .models import zomato
import Scripts
import json
import datetime
import subprocess
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor

from django.utils.safestring import mark_safe
from django.template import Context

from django.http import JsonResponse


# Create your views here.

def index(request):
    return render(request,'index.html')


def Encode(res):
    for column in res.columns[~res.columns.isin(['rate', 'cost', 'votes'])]:
        res[column] = res[column].factorize()[0]
    return res

def convert(data):
    lst=[]
 #Online_Order
    if data[0][0] is 'Yes':
        lst.append(1)
    else:
        lst.append(0)
 #Book_Table       
    if data[1][0] is 'Yes':
        lst.append(1)
    else:
        lst.append(0)
  #Type      
    if data[2][0] == 'Buffet':
        lst.append(0)
    elif data[2][0] == 'Cafes':
        lst.append(1)
    elif data[2][0] == 'Delivery':
        lst.append(2)
    elif data[2][0] == 'Desserts':
        lst.append(3)
    elif data[2][0] == 'Dine-out':
        lst.append(4)
    elif data[2][0] == 'Drinks & nightlife':
        lst.append(5)
    else:
        lst.append(6)   
        
    #City    
    if data[3][0] == 'Banashankari':
        lst.append(0)
    elif data[3][0] == 'Bannerghatta Road':
        lst.append(1)   
    elif data[3][0] == 'Basavanagudi':
        lst.append(2)
    elif data[3][0] == 'Bellandur':
        lst.append(3)
    elif data[3][0] == 'Brigade Road':
        lst.append(4)
    elif data[3][0] == 'Brookefield':
        lst.append(5)
    elif data[3][0] == 'BTM':
        lst.append(6)
    elif data[3][0] == 'Church Street':
        lst.append(7)
    elif data[3][0] == 'Electronic City':
        lst.append(8)
    elif data[3][0] == 'Frazer Town':
        lst.append(9)
    elif data[3][0] == 'HSR':
        lst.append(10)
    elif data[3][0] == 'Indiranagar':
        lst.append(11)
    elif data[3][0] == 'Jayanagar':
        lst.append(12)
    elif data[3][0] == 'JP Nagar':
        lst.append(13)
    elif data[3][0] == 'Kalyan Nagar':
        lst.append(14)
    elif data[3][0] == 'Kammanahalli':
        lst.append(15)
    elif data[3][0] == 'Koramangala 4th Block':
        lst.append(16)
    elif data[3][0] == 'Koramangala 5th Block':
        lst.append(17)
    elif data[3][0] == 'Koramangala 6th Block':
        lst.append(18)
    elif data[3][0] == 'Koramangala 7th Block':
        lst.append(19)
    elif data[3][0] == 'Lavelle Road':
        lst.append(20)
    elif data[3][0] == 'Malleshwaram':
        lst.append(21)
    elif data[3][0] == 'Marathahalli':
        lst.append(22)
    elif data[3][0] == 'MG Road':
        lst.append(23)
    elif data[3][0] == 'New BEL Road':
        lst.append(24)
    elif data[3][0] == 'Old Airport Road':
        lst.append(25)
    elif data[3][0] == 'Rajajinagar':
        lst.append(26)
    elif data[3][0] == 'Residency Road':
        lst.append(27)
    elif data[3][0] == 'Sarjapur Road':
        lst.append(28)
    else:
        lst.append(29)
    
    
    lst.append(data[4][0])
    lst.append(data[5][0])

    #a=RForest.predict(pd.DataFrame(lst).transpose())[0]  
    return(lst)
         
        

def modelFit(request):
    restaurants=pd.read_csv('C:\\Users\\Owner\\Downloads\\College\\Capstone Project\\zomato-bangalore-restaurants\\zomato.csv')
    df=restaurants.drop(['url','dish_liked','phone'],axis=1)
    df.duplicated().sum()
    df.drop_duplicates(inplace=True)
    df.isnull().sum()
    df.dropna(how='any',inplace=True)
    df = df.rename(columns={'approx_cost(for two people)':'cost','listed_in(type)':'type',
                                  'listed_in(city)':'city'})
    df['cost'] = df['cost'].astype(str) #Changing the cost to string
    df['cost'] = df['cost'].apply(lambda x: x.replace(',','.')) #Using lambda function to replace ',' from cost
    df['cost'] = df['cost'].astype(float) # Changing the cost to Float
    df = df.loc[df.rate !='NEW']
    df = df.loc[df.rate !='-'].reset_index(drop=True)
    remove_slash = lambda x: x.replace('/5', '') if type(x) == np.str else x
    df.rate = df.rate.apply(remove_slash).str.strip().astype('float')
    df.name = df.name.apply(lambda x:x.title())
    df.online_order.replace(('Yes','No'),(True, False),inplace=True)
    df.book_table.replace(('Yes','No'),(True, False),inplace=True)
    res=df[['online_order', 'book_table', 'type','city','rate','cost','votes']]
    res_en = Encode(res.copy())
    x = res_en.iloc[:,[0,1,2,3,5,6]]
    y = res_en['rate']
    x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=.1,random_state=353)
    RForest=RandomForestRegressor(n_estimators=500,random_state=329,min_samples_leaf=.0001)
    RForest.fit(x_train,y_train)
    #pd.DataFrame([1,0,0,0,800.0,918]).transpose()
    
    online_order=request.POST['online_order']
    book_table=request.POST['book_table']
    res_type=request.POST['type']
    city=request.POST['city']
    cost=request.POST['cost']
    votes=request.POST['votes']

    input_data=pd.DataFrame([online_order,book_table,res_type,city,cost,votes]).transpose()

    predicted_rating=convert(input_data) 
    a=RForest.predict(pd.DataFrame(predicted_rating).transpose()) 
    return render(request,'index.html',{'dests': a})

def news(request):
    df_cleaned=pd.read_csv('C:\\Users\\Owner\\Downloads\\College\\Capstone Project\\cleaned_restaurants.csv')
    total_restaurants=df_cleaned.shape[0]
    best_location=df_cleaned.location.value_counts().idxmax()
    best_cuisine=df_cleaned.cuisines.value_counts().idxmax()
    top_rating=df_cleaned.rate.value_counts().idxmax()

    df_cleaned["grouped_rating"] = pd.cut(df_cleaned["rate"], bins = [0, 2.0, 3.0, 4.0, 5.0], labels = ["1", "2", "3", "4"])
    a=pd.DataFrame(df_cleaned.groupby(['online_order','grouped_rating'])['name'].count().replace(np.nan,0))
    lst_rating=[{'Online_Order': 0,  'Rating_1': a['name'][0][0], 'Rating_2': a['name'][0][1],'Rating_3': a['name'][0][2],'Rating_4': a['name'][0][3]},
 {'Online_Order': 1, 'Rating_1': 1, 'Rating_2': a['name'][1][1],'Rating_3': a['name'][1][2],'Rating_4': a['name'][1][3]},
]

    order_lst = list()
    rating1_lst = list()
    rating2_lst = list()
    rating3_lst = list()
    rating4_lst = list()

    for i in lst_rating:
        order_lst.append(int(i['Online_Order']))
        rating1_lst.append(int(i['Rating_1']))
        rating2_lst.append(int(i['Rating_2']))
        rating3_lst.append(int(i['Rating_3']))
        rating4_lst.append(int(i['Rating_4']))

    #Split Packed Bubble Chart
    a_online=df_cleaned[df_cleaned['online_order']==True]
    grouped = a_online.groupby('rest_type')['name'].count().reset_index()
    x=grouped.sort_values('name', ascending=False).head(10).reset_index()

    a_offline=df_cleaned[df_cleaned['online_order']==False]
    grouped = a_offline.groupby('rest_type')['name'].count().reset_index()
    y=grouped.sort_values('name', ascending=False).head(10).reset_index()

    #lst_online_order_res=[{x['rest_type'][i] : x['name'][i] for i in range(len(x))}]
    #lst_offline_order_res=[{y['rest_type'][i] : y['name'][i] for i in range(len(y))}]

    #Testing
    lst_online_order_res=[{'"'+str(x['rest_type'][i])+'"' : str(x['name'][i])} for i in range(len(x))]
    lst_offline_order_res=[{ '"'+str(y['rest_type'][i])+'"' : str(y['name'][i])} for i in range(len(y))]

    #lst_offline_order=[(item) for item in (lst_offline_order_res)[0].values()]
    #lst_offline_restype=[item for item in (lst_offline_order_res)[0].keys()]
    
    #lst_online_order=[(item) for item in (lst_online_order_res)[0].values()]
    #lst_online_restype=[item for item in (lst_online_order_res)[0].keys()]

    #SJSON.parse(data.replace(/&quot;/g,'"'));
    #lst_offline_restype=mark_safe(lst_offline_restype) 
    #lst_online_restype=mark_safe(lst_online_restype)
    
    return render(request,'news.html',{'total_restaurants': total_restaurants,'best_location':best_location
    ,'best_cuisine':best_cuisine,'top_rating':top_rating,'order_lst': json.dumps(order_lst),
        'rating1_lst': json.dumps(rating1_lst),
        'rating2_lst': json.dumps(rating2_lst),
        'rating3_lst': json.dumps(rating3_lst),
        'rating4_lst': json.dumps(rating4_lst),
        'lst_online_order_res':lst_online_order_res,
        'lst_offline_order_res':lst_offline_order_res
        })

def about_us(request):
        return render(request,'about.html')

def about_index(request):
    
        return render(request,'index.html')




        




