from django.db import models
import pandas as pd

# Create your models here.
b = pd.DataFrame()

class zomato(models.Model):
    # Read the Data Frame
    def __init__(self, a):
        self.a = pd.read_csv('C:\\Users\\Owner\\Downloads\\College\\Capstone Project\\zomato-bangalore-restaurants\\zomato.csv')
        b = self.a
        
    def review(data):
        restaurants=pd.read_csv('C:\\Users\\Owner\\Downloads\\College\\Capstone Project\\zomato-bangalore-restaurants\\zomato.csv')
        df=restaurants.drop(['url','dish_liked','phone'],axis=1)
        data=b
        return data