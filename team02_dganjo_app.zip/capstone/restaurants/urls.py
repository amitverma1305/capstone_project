from django.urls import path
from django.conf.urls import url

from . import views


urlpatterns=[
    path('',views.index,name='index'),
    path('response',views.modelFit),
    url(r'^news',views.news,name='news'),
    url(r'^about_us',views.about_us,name='about'),
    url(r'^about_index',views.about_index,name='index'),
    #url('', views.get_data,name='news'),
]
